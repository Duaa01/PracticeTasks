package AbstractionTask;

public class Duck extends Animal{
    @Override
    public void makeSound() {
        System.out.println("The duck goes Quack Quack");
    }
}
