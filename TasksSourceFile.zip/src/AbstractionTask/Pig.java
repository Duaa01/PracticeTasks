package AbstractionTask;

public class Pig extends Animal{
    @Override
    public void makeSound() {
        System.out.println("The pig goes Oink Oink");
    }
}
